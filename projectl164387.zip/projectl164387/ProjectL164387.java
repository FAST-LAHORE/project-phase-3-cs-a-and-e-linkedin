/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectl164387;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import static projectl164387.dbConnection.c;

/**
 *
 * @author L164387
 */
public class ProjectL164387 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
      
        
        user u=user.getInstance();
       System.out.println( u.setValues(2,"ki", "edf", "ef", "ejjdf", "e2df", "e99df", "edfkk", "edfdd", "edfss", 250));
        //u.addCareers("programmer", "programmer", "jj", "dd");
        //article a=new article(1,"dddd","ddd","dd");
        //a.likeArticle(3);
      // a.likeArticle(3);
        //a.getTotalLikes();
        //System.out.println(a.likeCount);
        //jobs ji=new jobs();
        //jobs j1=new jobs();
        
       // j1=ji.searchJob(u);
        
        //Career_Interests c1=c.getResults(100);
        //System.out.println(c1.cid);
        //System.out.println(c1.locations);
        
         //c=new Career_Interests("first","entry","to","db");
         //jobs ji=new jobs();
         //jobs ji1=new jobs();
         
        // ArrayList <jobs> jo=new ArrayList <jobs>();
         //jo=ji.displayALL();
         //ji1=jo.get(2);
         
        
        
    }
    
}
