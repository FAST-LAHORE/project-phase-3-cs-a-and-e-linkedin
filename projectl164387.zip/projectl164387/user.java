/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectl164387;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Muntaha
 */
public class user {
    int userid;
      String username;
    String password;
    String name;
    String email;
    String country;
    String university;
    String degree;
    String profession;
    String website; 
    
    int count=0;
    int salary;
    //savedLibrary s1 = new savedLibrary();
    Career_Interests career=Career_Interests.getInstance() ;
    
    
    
    private static user u = new user();
    private user(){};
    
    public static user getInstance(){
        return u;
    }
    public boolean login(int id,String pass)
    {
        boolean result=false;
         Connection c=null;
         Statement st=null;
           ResultSet r=null;
         
        try {
                c= DriverManager.getConnection("jdbc:derby://localhost:1527/linkedin", "muntaha", "123456");
                //return c;
            } catch (SQLException ex) {
               // Logger.getLogger(dbConnection.class.getName()).log(Level.SEVERE, null, ex);
                //return null;
                System.out.println("no connection");
            }
        try {
            st=c.createStatement();
            r=st.executeQuery("SELECT * FROM MUNTAHA.USERINFO WHERE USERID="+id);
            if(r.next())
            {
                if(r.getString("password").equals(pass))
                {
                    result= true;
                }
                else
                {
                    result=false;
                }
            }
            else
            {
                result=false;
            }
        } catch (SQLException ex) {
            Logger.getLogger(user.class.getName()).log(Level.SEVERE, null, ex);
        }
        return result;
    }
    
    public boolean setValues(int userid,String un, String pass, String nm, String em, String coun, String uni, String deg, String prof, String web, int sal){
        username = un;
        password = pass;
        name = nm;
        email = em;
        country = coun;
        university = uni;
        degree = deg;
        profession = prof;
        website = web;
        salary = sal;
        this.userid=userid;
        //set these in database
          Connection c=null;
         Statement st=null;
           ResultSet r=null;
         
        try {
                c= DriverManager.getConnection("jdbc:derby://localhost:1527/linkedin", "muntaha", "123456");
                //return c;
            } catch (SQLException ex) {
               // Logger.getLogger(dbConnection.class.getName()).log(Level.SEVERE, null, ex);
                //return null;
                System.out.println("no connection");
            }
         boolean fl=true;
           boolean fl1=true;
        try {
            st=c.createStatement();
           
            //check if already present or not
           r=st.executeQuery("SELECT * FROM MUNTAHA.USERINFO WHERE USERID="+this.userid);
           while(r.next())
           {
                fl = false;
                count++;
                
                
           }
           
           
        } catch (SQLException ex) {
            Logger.getLogger(user.class.getName()).log(Level.SEVERE, null, ex);
        }
        int y=0;
        if(fl==true)
        {
        
        try {
            st=c.createStatement();
           //count=count+1;
            y=st.executeUpdate("INSERT INTO MUNTAHA.USERINFO VALUES("+count+",'"+un+"','"+pass+"','"+nm+"','"+em+"','"+coun+"','"+uni+"','"+deg+"','"+prof+"','"+web+"',"+sal+")" );                          
           
            fl1=true;
        } catch (SQLException ex) {
            Logger.getLogger(user.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        }
        else if(fl==false || y==0)
        {
            fl1=false;
        }
        //u.userid++;
        return fl1;
    }
    
    public String getUsername(){
        return username;
    }
    /*public void addCareer(Career_Interests c){
        this.career=Career_Interests.getInstance();
    }*/
     public boolean addCareers(String s, String j,String l,String i1){
         
        return this.career.add_Interests(s,j,l,i1,this.userid);
        
    }
    
    public Career_Interests getCareer(){
        return this.career.getResults(this.userid);
    }
    
}
