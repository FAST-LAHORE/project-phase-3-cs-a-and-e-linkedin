/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectl164387;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Muntaha
 */
public class article {
    int id;
    String title;
    String description;
    String publisher;
    int likeCount;
    
    public article(int ID, String t, String desc, String publisher){
        id = ID;
        title = t;
        description = desc;
        this.publisher = publisher;
    }
    public void likeArticle(int userid){
        //like can be zero or one 
        Connection c=null;
         Statement st=null;
         PreparedStatement ps = null;
           ResultSet r=null;
           
      
      
        try {
                c= DriverManager.getConnection("jdbc:derby://localhost:1527/linkedin", "muntaha", "123456");
                //return c;
            } catch (SQLException ex) {
               // Logger.getLogger(dbConnection.class.getName()).log(Level.SEVERE, null, ex);
                //return null;
                System.out.println("no connection");
            }
        //get results from data base and return tht object
        int y=0;
        try {
                st=c.createStatement();
                
               y = st.executeUpdate("INSERT INTO  MUNTAHA.ARTICLEANALYTICS VALUES("+userid+","+this.id+","+1+")" );
                
            } catch (SQLException ex) {
                System.out.println(ex);
            }
        
       
       
        
        
        
    }
    
    public void getTotalLikes(){
        Connection c=null;
         Statement st=null;
         PreparedStatement ps = null;
           ResultSet r=null;
           try {
                c= DriverManager.getConnection("jdbc:derby://localhost:1527/linkedin", "muntaha", "123456");
                //return c;
            } catch (SQLException ex) {
               // Logger.getLogger(dbConnection.class.getName()).log(Level.SEVERE, null, ex);
                //return null;
                System.out.println("no connection");
            }
        try {
            //get count of likes column
            st=c.createStatement();
            r=st.executeQuery("SELECT LIKES FROM MUNTAHA.ARTICLEANALYTICS WHERE ART_ID="+this.id);
            while(r.next())
            {
                this.likeCount+=r.getInt("likes");
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(article.class.getName()).log(Level.SEVERE, null, ex);
        }
           
           
        
    }
    
}
