/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectl164387;

/**
 *
 * @author Muntaha
 */
import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
public class dbConnection {
        protected static Connection c=null;
        protected static Statement st=null;
        protected static PreparedStatement ps = null;
        protected static ResultSet r=null;
        //establishing connection
        
            //c;
           //s=c.createStatement();
         //ps=c.prepareStatement("delete from L164387.MEDICINE where id=?");

    public   Connection GetdbConnection() {
            try {
                c= DriverManager.getConnection("jdbc:derby://localhost:1527/linkedin", "muntaha", "123456");
                return c;
            } catch (SQLException ex) {
                Logger.getLogger(dbConnection.class.getName()).log(Level.SEVERE, null, ex);
                return null;
            }
            
    }
    //functions to add career interets in db
    public boolean addInterests(int cid,String jobT,String loc,String ind,String status)
    {
        int y=0;
            try {
                st=c.createStatement();
                System.out.println("fff");
                y = st.executeUpdate("INSERT INTO  MUNTAHA.CAREERINTEREST VALUES("+cid+",'"+status+"','"+jobT+"','"+ind+"','"+loc+"')" );
            } catch (SQLException ex) {
                Logger.getLogger(dbConnection.class.getName()).log(Level.SEVERE, null, ex);
            }
            return y!=0;
    }
    public void displayInterest(int cid)
    {
            try {
                st=c.createStatement();
                r= st.executeQuery("SELECT * FROM MUNTAHA.CAREERINTEREST WHERE CID="+cid);
             
                    System.out.println(r.getInt("cid"));
                    System.out.println(r.getString("industries"));
                    System.out.println(r.getString("location"));
                    System.out.println(r.getString("status"));
                    System.out.println(r.getString("jobtitles"));
                    
                
            } catch (SQLException ex) {
                Logger.getLogger(dbConnection.class.getName()).log(Level.SEVERE, null, ex);
            }
    }
           
           
           
       
    
}
