/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectl164387;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Muntaha
 */
public class jobs {
       private int id;
    private String title;
   private String degree;
    private String description;
    private String company;
    private String country;
   private  int salary;
    public jobs()
    {
        
    }
   public jobs(int ID, String t, String deg, String desc, String com, String coun, int sal){  
        id = ID;
        title = t;
        degree = deg;
        description = desc;
        company = com;
        country = coun;
        salary = sal;
       
          
         
        
    }
   public jobs getJob(int id)
   {
      
       Connection c=null;
         Statement st=null;
         PreparedStatement ps = null;
           ResultSet r=null;
      
       jobs j=new jobs();
        //ArrayList <jobs> j=new ArrayList <jobs>();
        try {
                c= DriverManager.getConnection("jdbc:derby://localhost:1527/linkedin", "muntaha", "123456");
                //return c;
            } catch (SQLException ex) {
               // Logger.getLogger(dbConnection.class.getName()).log(Level.SEVERE, null, ex);
                //return null;
                System.out.println("no connection");
            }
        //get results from data base and return tht object
        try {
                st=c.createStatement();
                //ps=c.prepareStatement("SELECT * from L164387.MEDICINE where id=?");
                
                r= st.executeQuery("SELECT * FROM MUNTAHA.JOBT WHERE id="+id);
                while(r.next())
                {
                j.id=r.getInt("id");
                //System.out.println(oj.cid);
                 j.title = r.getString("title");
                    j.degree = r.getString("degree");
                    j.description = r.getString("description");
                    j.company = r.getString("company");
                    j.country = r.getString("country");
                    j.salary = r.getInt("salary");
                }
                    
                
            } catch (SQLException ex) {
                System.out.println("no record");
            }
        return j;
   }
   
   public jobs searchJob(user u)
   {
       Connection c=null;
         Statement st=null;
         PreparedStatement ps = null;
           ResultSet r=null;
           
      
       jobs j=new jobs();
        //ArrayList <jobs> j=new ArrayList <jobs>();
        try {
                c= DriverManager.getConnection("jdbc:derby://localhost:1527/linkedin", "muntaha", "123456");
                //return c;
            } catch (SQLException ex) {
               // Logger.getLogger(dbConnection.class.getName()).log(Level.SEVERE, null, ex);
                //return null;
                System.out.println("no connection");
            }
        //get results from data base and return tht object
        try {
                st=c.createStatement();
                ps=c.prepareStatement("SELECT * FROM MUNTAHA.JOBT where TITLE=?");
                //String q = "SELECT * FROM MUNTAHA.JOBT WHERE JOBT.TITLE='"+u.career.JobTitles+"'";
                ps.setString(1,u.career.JobTitles);
                r=ps.executeQuery();
                //r= st.executeQuery(q);
                  // System.out.println(u.career.JobTitles);
                   while(r.next())
                   {
                j.id=r.getInt("id");
                   System.out.println(u.career.JobTitles);
                 j.title = r.getString("title");
                    j.degree = r.getString("degree");
                    j.description = r.getString("description");
                    j.company = r.getString("company");
                    j.country = r.getString("country");
                    j.salary = r.getInt("salary");
                   }
                  //System.out.println("hhh");  
                
            } catch (SQLException ex) {
                System.out.println(ex);
            }
        return j;
       
       
   }
      
    
}
