/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectl164387;

import java.sql.Connection;
//import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author L164387
 */

public class Career_Interests {
    protected int u_id;
    protected int cid;
    protected String status; //introduction
    public String  JobTitles; //Job titles you're considering also it can be Types of jobs you're open to
    protected String  locations;//locations you'd like to work in
    protected String  industries; // Industries you are considering
   
    //default contructor
    
    private static Career_Interests ci= new Career_Interests();
    private Career_Interests(){};
    
    public static Career_Interests getInstance(){
        return ci;
    }
    
    
    //parameterized constructor
    public boolean add_Interests(String s, String j,String l,String i,int ui)
    {
        //index++;
        this.u_id=ui;
       
        this.status=s;
        this.JobTitles=j;
        this.industries=i;
        this.locations=l;
        //data connectivity
        Connection c=null;
         Statement st=null;
          
         
        try {
                c= DriverManager.getConnection("jdbc:derby://localhost:1527/linkedin", "muntaha", "123456");
                //return c;
            } catch (SQLException ex) {
               // Logger.getLogger(dbConnection.class.getName()).log(Level.SEVERE, null, ex);
                //return null;
                System.out.println("no connection");
            }
        int y=0;
            try {
                st=c.createStatement();
               // System.out.println("fff");
                 y = st.executeUpdate("INSERT INTO  MUNTAHA.CAREERINTEREST VALUES("+ui+",'"+j+"','"+s+"','"+i+"','"+l+"'"+")" );
            } catch (SQLException ex) {
                Logger.getLogger(dbConnection.class.getName()).log(Level.SEVERE, null, ex);
            }
            System.out.println(y);
        //boolean addInterests;
        return (y!=0);
        //addInterests = db1.addInterests(cid, j, l, i, s);
    }
    public Career_Interests getResults(int uid)
    {
        Connection c=null;
         Statement st=null;
         PreparedStatement ps = null;
           ResultSet r=null;
      
        Career_Interests oj=new Career_Interests();
        try {
                c= DriverManager.getConnection("jdbc:derby://localhost:1527/linkedin", "muntaha", "123456");
                //return c;
            } catch (SQLException ex) {
               // Logger.getLogger(dbConnection.class.getName()).log(Level.SEVERE, null, ex);
                //return null;
                System.out.println("no connection");
            }
        //get results from data base and return tht object
        try {
                st=c.createStatement();
                //ps=c.prepareStatement("SELECT * from L164387.MEDICINE where id=?");
                
                r= st.executeQuery("SELECT jobtitles,company,country,status,u_id FROM MUNTAHA.CAREERINTEREST WHERE u_id="+uid);
                while(r.next())
                {
                //oj.cid=r.getInt("c_id");
                //System.out.println(oj.cid);
                oj.JobTitles=r.getString("jobtitles");//getNString("jobtitles");
                oj.industries=r.getString("company");
                oj.locations=r.getString("country");
                oj.status=r.getString("status");
                oj.u_id=r.getInt("u_id");
                }
                    
                
            } catch (SQLException ex) {
                System.out.println("no record");
            }
        return oj;
    }
   
    
   //getters
    public String getStatus(){
        return this.status;
    }
    public String getJobStatus(){
        return this.JobTitles;
    }
     public String getIndustries(){
        return this.industries;
    }
      public String getLocations(){
        return this.locations;
    }
}
