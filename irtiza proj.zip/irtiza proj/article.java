/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jtableexp;

/**
 *
 * @author KHAWAJA ZEESHAUR
 */
public class article {
    
    int id;
    String title;
    String description;
    String publisher;
    
    article(int ID, String t, String desc, String publisher){
        id = ID;
        title = t;
        description = desc;
        this.publisher = publisher;
    }
}
