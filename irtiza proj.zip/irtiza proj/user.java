/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jtableexp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author KHAWAJA ZEESHAUR
 */

public class user {
    
    static String username;
    String password;
    String name;
    String email;
    String country;
    String university;
    String degree;
    String profession;
    String website; 
    int salary;
    SavedLib s1= new SavedLib();;
    ArrayList<job> AppliedJobs = new ArrayList();
//    private ArrayList<Post> posts;     //aik post do dafa show ho gi
//    private ArrayList<friendslist> friends=new ArrayList<>();;     //changing inheritance from aggregation
    
    private ArrayList<Message> sendmessages;
   private ArrayList<Message> recmessages;
    public static Connection myobj;
        public static Statement mystat=null;
        public static ResultSet myres=null;
        public static String query1=null;
        public static String queryusers="select * from IRTAZA.USERS";
        public static PreparedStatement sqlstat=null;   
        public static String queryrec = "select SENDER, MESSAGE from IRTAZA.MESSAGE where RECEIVER=?";
        public static String querysend = "select RECEIVER, MESSAGE from IRTAZA.MESSAGE where SENDER=?";

   
    
    
    
    
    
    private static user u = new user();
//    private user(){
//    posts = new ArrayList<>();
////        friends = new ArrayList<friendslist>();
//        sendmessages=new ArrayList<>();
//        recmessages=new ArrayList<>();
    
    
    public static user getInstance(){
        return u;
    }
    
    public void setValues(String un, String pass, String nm, String em, String coun, String uni, String deg, String prof, String web, int sal){
        username = un;
        password = pass;
        name = nm;
        email = em;
        country = coun;
        university = uni;
        degree = deg;
        profession = prof;
        website = web;
        salary = sal;
    }
    
    public static String getUsername(){
        return username;
    }
    
    public static ArrayList<Message> showreceive() throws SQLException
    {
       
            myobj=DriverManager.getConnection("jdbc:derby://localhost:1527/linkedin","irtaza","1234");
            mystat=myobj.createStatement();
        
       
sqlstat = myobj.prepareStatement(queryrec);
sqlstat.setString(1,user.getUsername());
ResultSet rs = sqlstat.executeQuery();
Message ms=new Message();
        String nmsg,nuser;
        ArrayList<Message> m=new ArrayList<Message>();
while (rs.next()) {
	nmsg = rs.getString("MESSAGE");
	nuser = rs.getString("SENDER");	
        
        System.out.println(nmsg+nuser);
//        nmsg=myres.getString("SENDER");
//               nuser=myres.getString("MESSAGE");
               ms.set(nmsg,nuser);
               m.add(ms);
               
        
}
       
       return m;
        
       
         
       
    }
    
    
    public static ArrayList<Message> showsend() throws SQLException
    {
       
            myobj=DriverManager.getConnection("jdbc:derby://localhost:1527/linkedin","irtaza","1234");
            mystat=myobj.createStatement();
       
       
sqlstat = myobj.prepareStatement(querysend);
sqlstat.setString(1,username);
ResultSet rs = sqlstat.executeQuery();
Message ms=new Message();
        String nmsg,nuser;
        ArrayList<Message> m=new ArrayList<Message>();
while (rs.next()) {
	nmsg = rs.getString("MESSAGE");
	nuser = rs.getString("RECEIVER");	
//        nmsg=myres.getString("SENDER");
//               nuser=myres.getString("MESSAGE");
               ms.set(nmsg,nuser);
               m.add(ms);
               
        
}
       
       return m;
        
       
    }
    
    public void makepost(String n) throws SQLException
    {
          myobj=DriverManager.getConnection("jdbc:derby://localhost:1527/linkedin","irtaza","1234");
            mystat=myobj.createStatement();
            
        sqlstat = myobj.prepareStatement("INSERT INTO IRTAZA.POSTS(ID,USERNAME,PID,POST) VALUES(?,?,?,?)");
        myres=mystat.executeQuery("select * from IRTAZA.POSTS");        
        int id=0;
        while(myres.next()){
               id=myres.getInt("ID");
            }
        id++;
        
        sqlstat.setInt(1,id);
         sqlstat.setString(2,user.getUsername());
         sqlstat.setInt(3, id);
         sqlstat.setString(4,n);
         
         
         int a = sqlstat.executeUpdate();
         
    }
    
    public ArrayList<Post> showmyposts() throws SQLException{
         ArrayList<Post> posts=new ArrayList<>();     //aik post do dafa show ho g
        myobj=DriverManager.getConnection("jdbc:derby://localhost:1527/linkedin","irtaza","1234");
            mystat=myobj.createStatement();
            
        sqlstat = myobj.prepareStatement("select * from IRTAZA.POSTS where username=?");
        sqlstat.setString(1,username);
        myres=sqlstat.executeQuery();
            int j=0;
            Post p;
            while(myres.next()){
               int id=myres.getInt("ID");
               String name= myres.getString("username");
               int pid = myres.getInt("pid");
               String post = myres.getString("post");
               p=new Post(id,post);
               posts.add(p);
                System.out.println(id+name+pid+post);
            
    }
            return posts;
    
    
    
}
    
    
    
    
}
    
    

    
    
   

