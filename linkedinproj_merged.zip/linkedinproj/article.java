/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package linkedinproj;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author KHAWAJA ZEESHAUR //like and total like muntaha
 */
public class article {
    
    int id;
    String title;
    String description;
    String publisher;
    int likeCount;
    article(int ID, String t, String desc, String publisher){
        id = ID;
        title = t;
        description = desc;
        this.publisher = publisher;
    }

    article() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    public void likeArticle(int art_id,int userid){
        //like can be zero or one 
        Connection c=null;
         Statement st=null;
         PreparedStatement ps = null;
           ResultSet r=null;
           
      int y=0;
      
        try {
                c= DriverManager.getConnection("jdbc:derby://localhost:1527/linkedin", "muntaha", "123456");
                 st=c.createStatement();
                
               y = st.executeUpdate("INSERT INTO  MUNTAHA.ARTICLEANALYTICS VALUES("+userid+","+art_id+","+1+")" );
                //return c;
            } catch (SQLException ex) {
               // Logger.getLogger(dbConnection.class.getName()).log(Level.SEVERE, null, ex);
                //return null;
                System.out.println("no connection");
            }
        //get results from data base and return tht object
        
       
        
       
       
        
        
        
    }
    
    public void getTotalLikes(int artid){
        Connection c=null;
         Statement st=null;
         PreparedStatement ps = null;
           ResultSet r=null;
           try {
                c= DriverManager.getConnection("jdbc:derby://localhost:1527/linkedin", "muntaha", "123456");
                //get count of likes column
            st=c.createStatement();
            r=st.executeQuery("SELECT LIKES FROM MUNTAHA.ARTICLEANALYTICS WHERE ART_ID="+artid);
            while(r.next())
            {
                this.likeCount+=r.getInt("likes");
            }
                //return c;
            } catch (SQLException ex) {
               // Logger.getLogger(dbConnection.class.getName()).log(Level.SEVERE, null, ex);
                //return null;
                System.out.println("no connection");
            }
        
           
           
        
    }
}
