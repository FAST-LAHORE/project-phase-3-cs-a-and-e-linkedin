/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package linkedinproj;

import java.util.ArrayList;

/**
 *
 * @author Dell
 */
public class Post {
    protected int id;
    protected String caption;
    
    
    Post(int i,String c)
    {
        id=i;
        caption=c;
//        user=new User_Account
    }
    
    
    public int getId()
    {
        return id;
    }
    
    public String getCaption()
    {
        return caption;
    }
    
}
