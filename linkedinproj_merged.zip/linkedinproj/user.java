/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package linkedinproj;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author KHAWAJA ZEESHAUR
 */

public class user {
    int userid;
    static String username;
    String password;
    String name;
    String email;
    String country;
    String university;
    String degree;
    String profession;
    String website; 
    int salary;
    static int count=0;
    SavedLib s1= new SavedLib();;
    ArrayList<job> AppliedJobs = new ArrayList();
//    private ArrayList<Post> posts;     //aik post do dafa show ho gi
//    private ArrayList<friendslist> friends=new ArrayList<>();;     //changing inheritance from aggregation
    
    private ArrayList<Message> sendmessages;
   private ArrayList<Message> recmessages;
    public static Connection myobj;
        public static Statement mystat=null;
        public static ResultSet myres=null;
        public static String query1=null;
        public static String queryusers="select * from MUNTAHA.USERINFO";
        public static PreparedStatement sqlstat=null;   
        public static String queryrec = "select SENDER, MESSAGE from MUNTAHA.MESSAGE where RECEIVER=?";
        public static String querysend = "select RECEIVER, MESSAGE from MUNTAHA.MESSAGE where SENDER=?";

    Career_Interests career=Career_Interests.getInstance() ;
    
    
    
    
    
    private static user u = new user();
//    private user(){
//    posts = new ArrayList<>();
////        friends = new ArrayList<friendslist>();
//        sendmessages=new ArrayList<>();
//        recmessages=new ArrayList<>();
    
    
    public static user getInstance(){
        return u;
    }
     public boolean login(int id,String pass)
    {
        
            boolean result=false;
            Connection c;
            Statement st=null;
            ResultSet r=null;
            
            try {
            //System.out.println(1);
            c= DriverManager.getConnection("jdbc:derby://localhost:1527/linkedin", "muntaha", "123456");
            System.out.println(12);
            st=c.createStatement();
            r=st.executeQuery("SELECT * FROM MUNTAHA.USERINFO WHERE USERID="+id);
            System.out.println(id);
            if(r.next())
            {
                if(r.getString("password").equals(pass))
                {
                    result= true;
                }
                else
                {
                    result=false;
                }
            }
            else
            {
                result=false;
            }
            //return c;
            
            
            
        } catch (SQLException ex) {
            Logger.getLogger(user.class.getName()).log(Level.SEVERE, null, ex);
        }
        return result;
    }
    
    public boolean setValues(String un, String pass, String nm, String em, String coun, String uni, String deg, String prof, String web, int sal){
        username = un;
        password = pass;
        name = nm;
        email = em;
        country = coun;
        university = uni;
        degree = deg;
        profession = prof;
        website = web;
        salary = sal;
       
        //set these in database
          Connection c=null;
         Statement st=null;
           ResultSet r=null;
         
        try {
                c= DriverManager.getConnection("jdbc:derby://localhost:1527/linkedin", "muntaha", "123456");
                //return c;
            } catch (SQLException ex) {
               // Logger.getLogger(dbConnection.class.getName()).log(Level.SEVERE, null, ex);
                //return null;
                System.out.println("no connection");
            }
         boolean fl=true;
           boolean fl1=true;
        try {
            st=c.createStatement();
           
            //check if already present or not
           r=st.executeQuery("SELECT * FROM MUNTAHA.USERINFO");
           while(r.next())
           {
                fl = false;
                count=r.getInt("userid")+count;
                
                
           }
           
           
        } catch (SQLException ex) {
            Logger.getLogger(user.class.getName()).log(Level.SEVERE, null, ex);
        }
        int y=0;
        if(fl==true)
        {
        
        try {
            st=c.createStatement();
           //count=count+1;
            this.userid=count;
            y=st.executeUpdate("INSERT INTO MUNTAHA.USERINFO VALUES("+count+",'"+un+"','"+pass+"','"+nm+"','"+em+"','"+coun+"','"+uni+"','"+deg+"','"+prof+"','"+web+"',"+sal+")" );                          
            
            fl1=true;
        } catch (SQLException ex) {
            Logger.getLogger(user.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        }
        else if(fl==false || y==0)
        {
            fl1=false;
        }
        //u.userid++;
        return fl1;
    }
    
    public static String getUsername(){
        return username;
    }
    
    public static ArrayList<Message> showreceive() throws SQLException
    {
       
            myobj=DriverManager.getConnection("jdbc:derby://localhost:1527/linkedin","muntaha","123456");
            mystat=myobj.createStatement();
        
       
sqlstat = myobj.prepareStatement(queryrec);
sqlstat.setString(1,user.getUsername());
ResultSet rs = sqlstat.executeQuery();
Message ms=new Message();
        String nmsg,nuser;
        ArrayList<Message> m=new ArrayList<Message>();
while (rs.next()) {
	nmsg = rs.getString("MESSAGE");
	nuser = rs.getString("SENDER");	
        
        System.out.println(nmsg+nuser);
//        nmsg=myres.getString("SENDER");
//               nuser=myres.getString("MESSAGE");
               ms.set(nmsg,nuser);
               m.add(ms);
               
        
}
       
       return m;
        
       
         
       
    }
    
    
    public static ArrayList<Message> showsend() throws SQLException
    {
       
            myobj=DriverManager.getConnection("jdbc:derby://localhost:1527/linkedin","muntaha","123456");
            mystat=myobj.createStatement();
       
       
sqlstat = myobj.prepareStatement(querysend);
sqlstat.setString(1,username);
ResultSet rs = sqlstat.executeQuery();
Message ms=new Message();
        String nmsg,nuser;
        ArrayList<Message> m=new ArrayList<Message>();
while (rs.next()) {
	nmsg = rs.getString("MESSAGE");
	nuser = rs.getString("RECEIVER");	
//        nmsg=myres.getString("SENDER");
//               nuser=myres.getString("MESSAGE");
               ms.set(nmsg,nuser);
               m.add(ms);
               
        
}
       
       return m;
        
       
    }
    
    public void makepost(String n) throws SQLException
    {
          myobj=DriverManager.getConnection("jdbc:derby://localhost:1527/linkedin","muntaha","123456");
            mystat=myobj.createStatement();
            
        sqlstat = myobj.prepareStatement("INSERT INTO MUNTAHA.POSTS(ID,USERNAME,PID,POST) VALUES(?,?,?,?)");
        myres=mystat.executeQuery("select * from MUNTAHA.POSTS");        
        int id=0;
        while(myres.next()){
               id=myres.getInt("ID");
            }
        id++;
        
        sqlstat.setInt(1,id);
         sqlstat.setString(2,u.username);
         sqlstat.setInt(3, id);
         sqlstat.setString(4,n);
         
         
         int a = sqlstat.executeUpdate();
         
    }
    
    public ArrayList<Post> showmyposts() throws SQLException{
         ArrayList<Post> posts=new ArrayList<>();     //aik post do dafa show ho g
        myobj=DriverManager.getConnection("jdbc:derby://localhost:1527/linkedin","muntaha","123456");
            mystat=myobj.createStatement();
            
        sqlstat = myobj.prepareStatement("select * from MUNTAHA.POSTS where username=?");
        sqlstat.setString(1,u.username);
        myres=sqlstat.executeQuery();
            int j=0;
            Post p;
            while(myres.next()){
               int id=myres.getInt("ID");
               String name= myres.getString("username");
               int pid = myres.getInt("pid");
               String post = myres.getString("post");
               p=new Post(id,post);
               posts.add(p);
                System.out.println(id+name+pid+post);
            
    }
            return posts;
    
    
    
}
    
     public boolean addCareers(String s, String j,String l,String i1){
         
        return this.career.add_Interests(s,j,l,i1,this.userid);
        
    }
    
    public Career_Interests getCareer(){
        return this.career.getResults(this.userid);
    }
    
    
}
    
    

    
    
   

