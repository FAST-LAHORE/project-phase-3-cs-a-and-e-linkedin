/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package linkedinproj;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
//import projectl164387.jobs;

/**
 *
 * @author KHAWAJA ZEESHAUR
 */
public class job {
    
    int id;
    String title;
    String degree;
    String description;
    String company;
    String country;
    int salary;
    
    job(int ID, String t, String deg, String desc, String com, String coun, int sal){  
        id = ID;
        title = t;
        degree = deg;
        description = desc;
        company = com;
        country = coun;
        salary = sal;
    }

    public job() {
       // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    public job searchJob(user u)
   {
       Connection c=null;
         Statement st=null;
         PreparedStatement ps = null;
           ResultSet r=null;
           
      
       job j=new job();
        //ArrayList <jobs> j=new ArrayList <jobs>();
        try {
                c= DriverManager.getConnection("jdbc:derby://localhost:1527/linkedin", "muntaha", "123456");
                //return c;
            } catch (SQLException ex) {
               // Logger.getLogger(dbConnection.class.getName()).log(Level.SEVERE, null, ex);
                //return null;
                System.out.println("no connection");
            }
        //get results from data base and return tht object
        try {
                st=c.createStatement();
                ps=c.prepareStatement("SELECT * FROM MUNTAHA.JOBT where TITLE=?");
                //String q = "SELECT * FROM MUNTAHA.JOBT WHERE JOBT.TITLE='"+u.career.JobTitles+"'";
                ps.setString(1,u.career.JobTitles);
                r=ps.executeQuery();
                //r= st.executeQuery(q);
                  // System.out.println(u.career.JobTitles);
                   while(r.next())
                   {
                j.id=r.getInt("id");
                   System.out.println(u.career.JobTitles);
                 j.title = r.getString("title");
                    j.degree = r.getString("degree");
                    j.description = r.getString("description");
                    j.company = r.getString("company");
                    j.country = r.getString("country");
                    j.salary = r.getInt("salary");
                   }
                  //System.out.println("hhh");  
                
            } catch (SQLException ex) {
                System.out.println(ex);
            }
        return j;
       
       
   }
}
